namespace CoreBancario.Api.Modelos;

/// <summary>Fila del maestro de mensajes (Administracion > Mensajes del sistema).</summary>
public record MensajeSistemaResponse(
    long IdMensaje, string Codigo, string Tipo, int HttpEstado, string Texto, string TextoDefecto,
    string? Descripcion, bool Modificado, string? ModificadoPor, DateTime? ModificadoEn);

public record MensajeEditarRequest(string Texto);

/// <summary>
/// Respuesta unica de las altas por API. Tipo: CLIENTE_CREADO (numeroCliente) | GESTION_PENDIENTE (numeroGestion + motivo) | ERROR.
/// Nunca incluye datos de otros clientes.
/// </summary>
public record RespuestaAltaApi(
    string Tipo, string Codigo, string Mensaje, string IdCorrelacion,
    string? NumeroCliente = null, long? IdCliente = null, string? NumeroGestion = null, string? Motivo = null,
    IReadOnlyList<string>? Detalles = null);
