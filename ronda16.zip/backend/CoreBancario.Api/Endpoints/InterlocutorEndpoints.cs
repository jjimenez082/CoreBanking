using CoreBancario.Api.Datos;
using CoreBancario.Api.Infraestructura;
using CoreBancario.Api.Modelos;

namespace CoreBancario.Api.Endpoints;

public static class InterlocutorEndpoints
{
    public static void MapInterlocutorEndpoints(this WebApplication app)
    {
        var grupo = app.MapGroup("/api/interlocutores")
            .RequireAuthorization();

        // RBAC (SEG-002): cada endpoint exige su propio codigo de
        // sec.OBJETO_AUTORIZACION, sembrado en modelo_fisico_transversal_minimo.sql.
        grupo.MapPost("/", AltaAsync).RequierePermiso("CLI_ALTA");
        grupo.MapGet("/", ListarAsync).RequierePermiso("CLI_CONSULTA");
        grupo.MapGet("/buscar", BuscarAsync).RequierePermiso("CLI_CONSULTA");
        grupo.MapGet("/{idInterlocutor:long}", DetalleAsync).RequierePermiso("CLI_CONSULTA");
        grupo.MapGet("/{idInterlocutor:long}/detalle", DetalleAsync).RequierePermiso("CLI_CONSULTA");
        grupo.MapGet("/{idInterlocutor:long}/360", Vista360Async).RequierePermiso("CLI_CONSULTA");

        // Todo cambio a datos de un cliente va por Gestion (principio del sistema):
        // este endpoint solo SOLICITA el cambio; se aplica cuando alguien con
        // GES_APROBAR lo aprueba (ver GestionEndpoints).
        grupo.MapPost("/{idInterlocutor:long}/modificacion", SolicitarModificacionAsync).RequierePermiso("CLI_EDICION");

        // Borradores del wizard de alta: privados de su propietario (cada consulta filtra por usuario).
        grupo.MapGet("/borradores", ListarBorradoresAsync).RequierePermiso("CLI_ALTA");
        grupo.MapGet("/borradores/{idBorrador:long}", ObtenerBorradorAsync).RequierePermiso("CLI_ALTA");
        grupo.MapPut("/borradores", GuardarBorradorAsync).RequierePermiso("CLI_ALTA");
        grupo.MapDelete("/borradores/{idBorrador:long}", EliminarBorradorAsync).RequierePermiso("CLI_ALTA");
    }

    private static IResult Error(ResultadoOperacion r) =>
        Results.Json(new { error = r.Error, mensaje = r.Mensaje, datos = r.Datos }, statusCode: r.Estado);

    private static async Task<IResult> ListarAsync(
        string? q, int? pagina, int? tamanoPagina, ActorContext actorContext, InterlocutorRepositorio repositorio)
    {
        var paginaValida = pagina is > 0 ? pagina.Value : 1;
        var tamanoValido = tamanoPagina is > 0 and <= 100 ? tamanoPagina.Value : 20;

        var (items, total) = await repositorio.ListarAsync(actorContext.IdCompania, q, paginaValida, tamanoValido);

        return Results.Ok(new InterlocutorListaResponse(items, paginaValida, tamanoValido, total));
    }

    /// <summary>Busqueda global de la barra superior: cualquier rol; el usuario elige y abre la vista 360.</summary>
    private static async Task<IResult> BuscarAsync(string? q, ActorContext actorContext, InterlocutorRepositorio repositorio)
        => Results.Ok(await repositorio.BuscarAsync(actorContext.IdCompania, q));

    private static async Task<IResult> AltaAsync(
        InterlocutorAltaRequest request, ActorContext actorContext, InterlocutorRepositorio repositorio, GestionRepositorio gestiones,
        HttpContext http, MensajesRepositorio mensajes, IdempotenciaRepositorio idempotencia)
    {
        // Backoffice (usuario nombrado): el alta es una gestion; segun la regla de aprobacion el cliente se crea de inmediato o al aprobarse.
        if (!actorContext.EsIntegracion)
        {
            var g = await gestiones.SolicitarAltaInterlocutorAsync(actorContext, request);
            if (!g.Exito) return Error(g);

            var idCliente = await gestiones.ClienteCreadoPorAltaAsync(g.Id!.Value);
            var ficha = idCliente is null ? null : await repositorio.ObtenerDetalleAsync(actorContext.IdCompania, idCliente.Value);
            var respuesta = new InterlocutorAltaGestionResponse(g.Id.Value, g.Numero, idCliente is not null, ficha);
            return idCliente is null
                ? Results.Json(respuesta, statusCode: StatusCodes.Status202Accepted)
                : Results.Created($"/api/interlocutores/{idCliente}", respuesta);
        }

        // Integraciones (API): el alta tambien es una gestion. Contrato de respuesta (ver AltaApiAsync):
        //   201 CLIENTE_CREADO | 202 GESTION_PENDIENTE | 4xx/5xx ERROR; siempre con Idempotency-Key e idCorrelacion.
        return await AltaApiAsync(request, actorContext, gestiones, http, mensajes, idempotencia);
    }

    private static readonly Dictionary<string, string> AliasError = new(StringComparer.OrdinalIgnoreCase)
    {
        ["RANGO_AGOTADO"] = "NUMERACION_AGOTADA",
        ["RANGO_NO_CONFIGURADO"] = "NUMERACION_AGOTADA",
        ["TIPO_GESTION_NO_CONFIGURADO"] = "CONFIGURACION_INCOMPLETA",
        ["ROL_NO_CONFIGURADO"] = "CONFIGURACION_INCOMPLETA",
    };

    private static async Task<IResult> AltaApiAsync(
        InterlocutorAltaRequest request, ActorContext actor, GestionRepositorio gestiones,
        HttpContext http, MensajesRepositorio mensajes, IdempotenciaRepositorio idempotencia)
    {
        var correlacion = http.Request.Headers["X-Correlation-Id"].FirstOrDefault()?.Trim();
        if (string.IsNullOrEmpty(correlacion) || correlacion.Length > 64) correlacion = Guid.NewGuid().ToString("N");
        http.Response.Headers["X-Correlation-Id"] = correlacion;

        // Arma la respuesta desde el maestro de mensajes (el texto es parametrizable; el codigo es estable).
        async Task<(int Estado, RespuestaAltaApi Cuerpo)> Armar(string codigo, Dictionary<string, string>? valores = null,
            string? tipo = null, string? numeroCliente = null, long? idCliente = null, string? numeroGestion = null, string? motivo = null, IReadOnlyList<string>? detalles = null)
        {
            var m = await mensajes.ResolverAsync(actor.IdCompania, codigo, valores)
                    ?? await mensajes.ResolverAsync(actor.IdCompania, "ERROR_INTERNO")
                    ?? new MensajesRepositorio.Resuelto("ERROR_INTERNO", "ERROR", 500, "Ocurrio un error inesperado.");
            var esError = m.Tipo == "ERROR";
            return (m.Http, new RespuestaAltaApi(esError ? "ERROR" : tipo ?? "INFO", m.Codigo, m.Texto, correlacion, numeroCliente, idCliente, numeroGestion, motivo, detalles));
        }
        static IResult Salida(int estado, RespuestaAltaApi cuerpo) => Results.Json(cuerpo, statusCode: estado);

        // 1. Idempotency-Key obligatoria.
        var llave = http.Request.Headers["Idempotency-Key"].FirstOrDefault()?.Trim();
        if (string.IsNullOrEmpty(llave)) { var (e, b) = await Armar("IDEMPOTENCY_KEY_REQUERIDA"); return Salida(e, b); }
        if (llave.Length is < 8 or > 100) { var (e, b) = await Armar("IDEMPOTENCY_KEY_INVALIDA"); return Salida(e, b); }

        // La integracion no puede imponer borradores, devoluciones, prospectos ni revisiones: eso es del Backoffice.
        var req = request with { IdBorrador = null, IdGestionDevuelta = null, IdProspecto = null, RevisionDuplicados = null };
        var huella = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(
            System.Text.Encoding.UTF8.GetBytes(System.Text.Json.JsonSerializer.Serialize(req)))).ToLowerInvariant();

        // 2. Reserva (o repeticion) de la llave.
        const string operacion = "INTERLOCUTOR_ALTA";
        var (nueva, reg) = await idempotencia.ReservarAsync(actor, operacion, llave, huella, correlacion);
        if (!nueva)
        {
            if (reg.Huella != huella) { var (e, b) = await Armar("IDEMPOTENCY_KEY_CONFLICTO"); return Salida(e, b); }
            if (reg.Estado != "COMPLETA") { var (e, b) = await Armar("IDEMPOTENCY_EN_PROCESO"); return Salida(e, b); }
            http.Response.Headers["Idempotent-Replay"] = "true";
            return Results.Content(reg.Respuesta ?? "{}", "application/json", System.Text.Encoding.UTF8, reg.HttpEstado ?? 200);
        }

        try
        {
            // 3. Alta como gestion: la regla de aprobacion decide si se aplica ya o queda pendiente.
            var g = await gestiones.SolicitarAltaInterlocutorAsync(actor, req);

            int estado; RespuestaAltaApi cuerpo;
            if (!g.Exito)
            {
                var codigo = AliasError.GetValueOrDefault(g.Error ?? "", (g.Error ?? "ERROR_INTERNO").ToUpperInvariant());
                var valores = g.Datos as Dictionary<string, string>;
                IReadOnlyList<string>? detalles = codigo == "DATOS_INVALIDOS" && g.Mensaje is not null
                    ? g.Mensaje.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries) : null;
                (estado, cuerpo) = await Armar(codigo, valores, detalles: detalles);
                // Un codigo sin mensaje en el maestro nunca expone el texto interno (podria nombrar datos de otros clientes).
            }
            else
            {
                var idCliente = await gestiones.ClienteCreadoPorAltaAsync(g.Id!.Value);
                if (idCliente is not null)
                {
                    var numero = await gestiones.NumeroClienteAsync(idCliente.Value);
                    (estado, cuerpo) = await Armar("CLIENTE_CREADO", new() { ["numeroCliente"] = numero ?? "" }, "CLIENTE_CREADO", numeroCliente: numero, idCliente: idCliente);
                }
                else
                {
                    var porCoincidencia = g.Datos as string == "REVISION_COINCIDENCIAS";
                    (estado, cuerpo) = await Armar(
                        porCoincidencia ? "GESTION_PENDIENTE_COINCIDENCIAS" : "GESTION_PENDIENTE_APROBACION",
                        new() { ["numeroGestion"] = g.Numero ?? "" }, "GESTION_PENDIENTE", numeroGestion: g.Numero,
                        motivo: porCoincidencia ? "REVISION_COINCIDENCIAS" : "APROBACION_REQUERIDA");
                }
            }

            if (estado >= 500) { await idempotencia.LiberarAsync(reg.Id); return Salida(estado, cuerpo); }
            await idempotencia.CompletarAsync(reg.Id, estado, System.Text.Json.JsonSerializer.Serialize(cuerpo,
                new System.Text.Json.JsonSerializerOptions(System.Text.Json.JsonSerializerDefaults.Web)));
            return Salida(estado, cuerpo);
        }
        catch
        {
            await idempotencia.LiberarAsync(reg.Id);
            throw;
        }
    }

    private static async Task<IResult> DetalleAsync(
        long idInterlocutor, ActorContext actorContext, InterlocutorRepositorio repositorio)
    {
        var detalle = await repositorio.ObtenerDetalleAsync(actorContext.IdCompania, idInterlocutor);

        return detalle is null
            ? Results.NotFound(new { error = "no_encontrado", idInterlocutor })
            : Results.Ok(detalle);
    }

    private static async Task<IResult> Vista360Async(
        long idInterlocutor, ActorContext actorContext, InterlocutorRepositorio repositorio)
    {
        var vista = await repositorio.Obtener360Async(actorContext.IdCompania, idInterlocutor);

        return vista is null
            ? Results.NotFound(new { error = "no_encontrado", idInterlocutor })
            : Results.Ok(vista);
    }

    private static async Task<IResult> SolicitarModificacionAsync(
        long idInterlocutor, InterlocutorModificacionRequest request, ActorContext actorContext, GestionRepositorio gestiones)
    {
        var r = await gestiones.SolicitarModificacionInterlocutorAsync(actorContext, idInterlocutor, request);

        return r.Exito
            ? Results.Created($"/api/gestiones/{r.Id}", await gestiones.ObtenerDetalleAsync(actorContext, r.Id!.Value))
            : Error(r);
    }

    // ----- Borradores ----------------------------------------------------------------

    private static async Task<IResult> ListarBorradoresAsync(ActorContext actorContext, InterlocutorRepositorio repositorio)
        => Results.Ok(await repositorio.ListarBorradoresAsync(actorContext));

    private static async Task<IResult> ObtenerBorradorAsync(
        long idBorrador, ActorContext actorContext, InterlocutorRepositorio repositorio)
    {
        var b = await repositorio.ObtenerBorradorAsync(actorContext, idBorrador);
        return b is null ? Results.NotFound(new { error = "borrador_no_encontrado", idBorrador }) : Results.Ok(b);
    }

    private static async Task<IResult> GuardarBorradorAsync(
        BorradorGuardarRequest request, ActorContext actorContext, InterlocutorRepositorio repositorio)
    {
        var r = await repositorio.GuardarBorradorAsync(actorContext, request);
        if (!r.Exito) return Error(r);

        var guardado = await repositorio.ObtenerBorradorAsync(actorContext, r.Id!.Value);
        return Results.Ok(new { idBorrador = r.Id, venceEn = guardado?.VenceEn });
    }

    private static async Task<IResult> EliminarBorradorAsync(
        long idBorrador, ActorContext actorContext, InterlocutorRepositorio repositorio)
    {
        var r = await repositorio.EliminarBorradorAsync(actorContext, idBorrador);
        return r.Exito ? Results.NoContent() : Error(r);
    }
}
