import { NotificacionesPage } from "./pages/NotificacionesPage";
import { Navigate, Route, Routes, useLocation, useSearchParams } from "react-router-dom";
import { RutaProtegida } from "./components/RutaProtegida";
import { Layout } from "./components/Layout";
import { PermisosProvider } from "./contexts/PermisosContext";
import { DashboardPage } from "./pages/DashboardPage";
import { GestionesPage } from "./pages/GestionesPage";
import { GestionesInicioPage } from "./pages/GestionesInicioPage";
import { GestionesReasignacionPage } from "./pages/GestionesReasignacionPage";
import { InterlocutoresInicioPage } from "./pages/InterlocutoresInicioPage";
import { InterlocutoresConsultaPage } from "./pages/InterlocutoresConsultaPage";
import { Interlocutor360Page } from "./pages/Interlocutor360Page";
import { ClienteWizardPage } from "./pages/ClienteWizardPage";
import { ProspectosPage } from "./pages/ProspectosPage";
import { BorradoresPage } from "./pages/BorradoresPage";
import { SeguridadPage } from "./pages/SeguridadPage";
import { ListasValoresPage } from "./pages/ListasValoresPage";
import { NumeracionPage } from "./pages/NumeracionPage";
import { MensajesSistemaPage } from "./pages/MensajesSistemaPage";
import { ReglasAprobacionPage } from "./pages/ReglasAprobacionPage";
import { GruposPage } from "./pages/GruposPage";
import { DivisionTerritorialPage } from "./pages/DivisionTerritorialPage";
import { UnidadesPage } from "./pages/UnidadesPage";
import { UsuariosPage } from "./pages/UsuariosPage";
import { MonedasPage } from "./pages/MonedasPage";
import { TipoCambioPage } from "./pages/TipoCambioPage";
import { FeriadosPage } from "./pages/FeriadosPage";
import { ParametrosPage } from "./pages/ParametrosPage";
import { AuditoriaPage } from "./pages/AuditoriaPage";
import { AdministracionInicioPage } from "./pages/AdministracionInicioPage";
import { IntegracionesPage } from "./pages/IntegracionesPage";

/** /gestiones es el launchpad; los enlaces con ?ver=N (campanita, auditoría) abren ese detalle en la consulta. */
function GestionesRuta() {
  const [params] = useSearchParams();
  const location = useLocation();
  const ver = params.get("ver");
  return ver
    ? <Navigate to={`/gestiones/consulta?ver=${encodeURIComponent(ver)}`} state={location.state} replace />
    : <GestionesInicioPage />;
}

function App() {
  return (
    <RutaProtegida>
      <PermisosProvider>
        <Layout>
          <Routes>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/notificaciones" element={<NotificacionesPage />} />
            <Route path="/gestiones" element={<GestionesRuta />} />
            <Route path="/gestiones/consulta" element={<GestionesPage modo="consulta" />} />
            <Route path="/gestiones/aprobacion" element={<GestionesPage modo="aprobacion" />} />
            <Route path="/gestiones/reasignacion" element={<GestionesReasignacionPage />} />
            <Route path="/interlocutores" element={<InterlocutoresInicioPage />} />
            <Route path="/interlocutores/consulta" element={<InterlocutoresConsultaPage />} />
            <Route path="/interlocutores/clientes/nuevo" element={<ClienteWizardPage />} />
            <Route path="/interlocutores/clientes/:id/modificar" element={<ClienteWizardPage />} />
            <Route path="/interlocutores/prospectos" element={<ProspectosPage />} />
            <Route path="/interlocutores/borradores" element={<BorradoresPage />} />
            <Route path="/interlocutores/:id" element={<Interlocutor360Page />} />
            <Route path="/administracion" element={<AdministracionInicioPage />} />
            <Route path="/seguridad" element={<SeguridadPage />} />
            <Route path="/listas-valores" element={<ListasValoresPage />} />
            <Route path="/numeracion" element={<NumeracionPage />} />
            <Route path="/mensajes" element={<MensajesSistemaPage />} />
            <Route path="/reglas-aprobacion" element={<ReglasAprobacionPage />} />
            <Route path="/grupos" element={<GruposPage />} />
            <Route path="/division-territorial" element={<DivisionTerritorialPage />} />
            <Route path="/unidades" element={<UnidadesPage />} />
            <Route path="/usuarios" element={<UsuariosPage />} />
            <Route path="/monedas" element={<MonedasPage />} />
            <Route path="/tipo-cambio" element={<TipoCambioPage />} />
            <Route path="/feriados" element={<FeriadosPage />} />
            <Route path="/parametros" element={<ParametrosPage />} />
            <Route path="/auditoria" element={<AuditoriaPage />} />
            <Route path="/integraciones" element={<IntegracionesPage />} />
          </Routes>
        </Layout>
      </PermisosProvider>
    </RutaProtegida>
  );
}

export default App;
