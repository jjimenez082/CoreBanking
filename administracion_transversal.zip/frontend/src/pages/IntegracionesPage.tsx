import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import { useApiClient } from "../api/useApiClient";
import { TablaDatos, type ColumnaTabla } from "../components/TablaDatos";
import { mensajeError } from "../api/mensajes";
import type { CatalogoItemResponse, IntegracionFila } from "../api/tipos";

/**
 * Administración › Usuarios de integración (permiso INT_ADMINISTRACION). Cada integración (CRM, onboarding digital, web, móvil...)
 * tiene un canal fijo: cuando da de alta un cliente por la API, el canal de origen lo asigna el servidor, no lo decide quien llama.
 */
export function IntegracionesPage() {
  const api = useApiClient();
  const [filas, setFilas] = useState<IntegracionFila[]>([]);
  const [canales, setCanales] = useState<CatalogoItemResponse[]>([]);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [exito, setExito] = useState<string | null>(null);
  const [sel, setSel] = useState<Set<string | number>>(new Set());
  const [editando, setEditando] = useState(false);
  const [idCanal, setIdCanal] = useState(0);
  const [errorForm, setErrorForm] = useState<string | null>(null);

  const cargar = useCallback(async () => {
    setCargando(true); setError(null);
    try {
      const [i, c] = await Promise.all([
        api.get<IntegracionFila[]>("/api/integraciones"),
        api.get<CatalogoItemResponse[]>("/api/catalogos/listas/CANAL"),
      ]);
      setFilas(i.data); setCanales(c.data); setSel(new Set());
    } catch (e) { setError(mensajeError(e, "No se pudieron cargar los usuarios de integración.")); }
    finally { setCargando(false); }
  }, [api]);
  useEffect(() => { void cargar(); }, [cargar]);

  const columnas: ColumnaTabla<IntegracionFila>[] = useMemo(() => [
    { clave: "nombre", encabezado: "Integración", render: (r) => r.nombre, textoBusqueda: (r) => r.nombre },
    { clave: "client", encabezado: "Client ID (Keycloak)", render: (r) => <code>{r.clientId}</code>, textoBusqueda: (r) => r.clientId },
    { clave: "canal", encabezado: "Canal fijo", render: (r) => r.canalNombre ?? <em>Sin canal (no puede dar altas)</em>, textoBusqueda: (r) => r.canalNombre ?? "" },
    { clave: "estado", encabezado: "Estado", render: (r) => r.estado, textoBusqueda: (r) => r.estado },
  ], []);

  const idSel = sel.size === 1 ? Number(Array.from(sel)[0]) : null;
  const fila = filas.find((f) => f.idUsuarioIntegracion === idSel) ?? null;

  async function guardar(e: FormEvent) {
    e.preventDefault();
    if (!fila) return;
    setErrorForm(null);
    try { await api.put(`/api/integraciones/${fila.idUsuarioIntegracion}/canal`, { idCanal }); setExito("Canal asignado."); setEditando(false); await cargar(); }
    catch (err) { setErrorForm(mensajeError(err, "No se pudo asignar el canal.")); }
  }

  return (
    <div>
      <h1>Usuarios de integración</h1>
      <p className="nota">Cuentas de servicio que llaman a la API. El canal fijo se asigna al cliente al darlo de alta por esa integración. Los canales se mantienen en Listas de Valores (CANAL).</p>
      {error && <p className="mensaje-error">{error}</p>}
      {exito && <p className="mensaje-exito">{exito}</p>}
      <TablaDatos
        columnas={columnas} filas={filas} claveFila={(f) => f.idUsuarioIntegracion}
        seleccion={sel} onCambiarSeleccion={setSel} cargando={cargando}
        mensajeVacio="No hay usuarios de integración registrados."
        comandos={[
          { clave: "canal", etiqueta: "Asignar canal", icono: "✎", requiereSeleccion: "una", onClick: () => { if (!fila) return; setExito(null); setErrorForm(null); setIdCanal(fila.idCanal ?? 0); setEditando(true); } },
          { clave: "actualizar", etiqueta: "Actualizar", icono: "↻", onClick: () => void cargar() },
        ]}
      />
      {editando && fila && (
        <section className="panel-formulario">
          <h3>Canal de {fila.nombre}</h3>
          {errorForm && <p className="mensaje-error">{errorForm}</p>}
          <form className="formulario" onSubmit={guardar}>
            <label>Canal
              <select value={idCanal} onChange={(e) => setIdCanal(Number(e.target.value))} required>
                <option value={0}>Seleccione...</option>
                {canales.map((c) => (<option key={c.id} value={c.id}>{c.nombre}</option>))}
              </select>
            </label>
            <div style={{ display: "flex", gap: "0.5rem" }}>
              <button type="submit" disabled={!idCanal}>Guardar</button>
              <button type="button" className="boton-secundario" onClick={() => setEditando(false)}>Cancelar</button>
            </div>
          </form>
        </section>
      )}
    </div>
  );
}
