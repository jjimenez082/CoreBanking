using Dapper;
using Microsoft.Data.SqlClient;
using CoreBancario.Api.Infraestructura;
using CoreBancario.Api.Modelos;

namespace CoreBancario.Api.Datos;

/// <summary>Usuarios de integracion (sec.USUARIO_INTEGRACION): consulta y asignacion de su canal fijo.</summary>
public class IntegracionRepositorio
{
    public const string ObjetoAdministracion = "INT_ADMINISTRACION";
    public const string Entidad = "USUARIO_INTEGRACION";

    private readonly TenantContext _tenant;
    public IntegracionRepositorio(TenantContext tenant) { _tenant = tenant; }
    private SqlConnection NuevaConexion() => new(_tenant.ConnectionString);

    public async Task<IReadOnlyList<IntegracionResponse>> ListarAsync(long idCompania)
    {
        using var c = NuevaConexion();
        var filas = await c.QueryAsync(
            """
            SELECT ui.id_usuario_integracion, ui.client_id_iam, ui.nombre, ui.estado, ui.id_canal, ca.nombre AS canal_nombre
            FROM sec.USUARIO_INTEGRACION ui
            LEFT JOIN gen.LISTA_VALORES_ITEM ca ON ca.id_lista_valores_item = ui.id_canal
            WHERE ui.id_compania = @idCompania ORDER BY ui.nombre
            """, new { idCompania });
        return filas.Select(f => new IntegracionResponse(
            (long)f.id_usuario_integracion, (string)f.client_id_iam, (string)f.nombre, (string)f.estado, (long?)f.id_canal, (string?)f.canal_nombre))
            .Cast<IntegracionResponse>().ToList();
    }

    public async Task<ResultadoOperacion> AsignarCanalAsync(ActorContext actor, long idIntegracion, long idCanal)
    {
        using var c = NuevaConexion();
        c.Open();
        using var tx = c.BeginTransaction();
        try
        {
            var a = await c.QuerySingleOrDefaultAsync(
                "SELECT id_canal FROM sec.USUARIO_INTEGRACION WITH (UPDLOCK) WHERE id_usuario_integracion = @id AND id_compania = @c",
                new { id = idIntegracion, c = actor.IdCompania }, tx);
            if (a is null) return ResultadoOperacion.Fallo(404, "no_encontrado", "No existe el usuario de integracion.");
            var error = await InterlocutorRepositorio.ValidarCanalAsync(c, tx, idCanal, null);
            if (error is not null) return ResultadoOperacion.Fallo(400, "datos_invalidos", error);
            if ((long?)a.id_canal == idCanal) return ResultadoOperacion.Ok(idIntegracion);

            await c.ExecuteAsync("UPDATE sec.USUARIO_INTEGRACION SET id_canal = @canal WHERE id_usuario_integracion = @id", new { canal = idCanal, id = idIntegracion }, tx);
            await Auditoria.CambioAsync(c, tx, actor, Entidad, idIntegracion, "id_canal", ((long?)a.id_canal)?.ToString(), idCanal.ToString());
            tx.Commit();
            return ResultadoOperacion.Ok(idIntegracion);
        }
        catch { tx.Rollback(); throw; }
    }
}
